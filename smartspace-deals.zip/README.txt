SmartSpace Deals Website

This is a static HTML site for an Amazon affiliate marketing project.
To use:

1. Open index.html in your browser.
2. Deploy to GitHub Pages, Netlify, or Vercel for free hosting.

Make sure to add your affiliate links and customize blog content.

Contact: [your-email@example.com]
